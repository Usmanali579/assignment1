"use strict";
//Task1
let person = "Usman";
console.log("Hello", person, "would you like to learn some Python today?");
//Task2
let result = person.toLowerCase();
let result1 = person.toUpperCase();
console.log(result);
console.log(result1);
console.log(person.charAt(0).toUpperCase() + person.slice(1).toLowerCase());
//Task3
//simply storing the printing the message in double quotes!
let author = "Albert Einstein";
console.log(author, "once said,", "\"A person who never made a mistake never tried anything new\"");
//Task4
//Printing the message by storing it in the variable
let famous_person = "Albert Einstein";
let message = "\"A person who never made a mistake never tried anything new\"";
console.log(famous_person, "once said", message);
//Task5
// Store the person's name with whitespace characters
let name1 = "\t\n   Usman Ali \n\t";
// Print the name with the whitespace
console.log("Name with whitespace: " + name1);
// Remove the whitespace from the name
name1 = name1.trim();
// Print the name without the whitespace
console.log("Name without whitespace: " + name1);
// Task 6 7
// Addition
let res = 5 + 3;
console.log(res); // Output: 8
// Subtraction
res = 12 - 4;
console.log(res); // Output: 8
// Multiplication
res = 2 * 4;
console.log(res); // Output: 8
// Division
res = 16 / 2;
console.log(res); // Output: 8
//Task8
// Store your favorite number in a variable
let favoriteNumber = 56;
// Create a message that reveals your favorite number
let mess = "My favorite number is " + favoriteNumber + "!";
// Print the message to the console
console.log(mess);
//Task9 is simply to write the comments in the each task that what your task is actually doing!
//Task 10
// Store the names of your friends in an array
let names = ["Tayab", "Wahaj", "Asad", "Ahmad"];
// Print each person's name by accessing each element in the array
for (let i = 0; i < names.length; i++) {
    console.log(names[i]);
    //task11
    console.log("Hello, " + names[i] + "! How are you doing today?");
}
//Task12
// Store a list of favorite modes of transportation
let vehicles = ["Honda motorcycle", "Tesla Model S", "Boeing 747", "Cannondale road bike"];
// Print a series of statements about each item in the list
for (let i = 0; i < vehicles.length; i++) {
    console.log("I would like to own a " + vehicles[i]);
}
//Task 13
let people = ["Daniyal", "Zeeshaan", "Mustafa Raza"];
for (let i = 0; i < people.length; i++) {
    console.log("I would like to invite you on dinner " + people[i]);
}
//Task14
// Print the original guest list
console.log("Original guest list: " + people);
// Update the guest list
people[2] = "Rehan";
// Print the updated guest list
console.log("Updated guest list: " + people);
// Send out new invitations
for (let i = 0; i < people.length; i++) {
    console.log("I would like to invite you on dinner " + people[i]);
}
//Task 15
let people1 = ["Daniyal", "Zeeshaan", "Mustafa Raza"];
// Print the original guest list
console.log("Original guest list: " + people1);
console.log(people1[2], "Could not come to the dinner");
// Update the guest list
people1[2] = "Rehan";
// Print the updated guest list
console.log("Updated guest list: " + people1);
// Send out new invitations
for (let i = 0; i < people1.length; i++) {
    console.log("I would like to invite you on dinner " + people1[i]);
}
//Task 16
// Define the original guest list
let guestList = ["Danyal", "Zeeshan", "Mustafa Raza"];
// Print the original guest list
console.log("Original guest list: " + guestList);
// Inform people that you found a bigger dinner table
console.log("Great news! I found a bigger dinner table!");
// Add one new guest to the beginning of the array
guestList.unshift("Rehan");
// Add one new guest to the middle of the array
guestList.splice(3, 0, "Ali");
// Use append() to add one new guest to the end of the list
guestList.push("JoJo");
// Print a new set of invitation messages for each person in your list
for (let i = 0; i < guestList.length; i++) {
    console.log("Dear " + guestList[i] + ", You are invited to a dinner party!");
}
//Task 17
console.log("Sorry, we can only invite two guests for dinner.");
while (guestList.length > 2) {
    let removedGuest = guestList.pop();
    console.log("Sorry, " + removedGuest + ", I can't invite you to dinner.");
}
console.log(guestList[0] + " and " + guestList[1] + ", you're still invited to dinner!");
guestList.pop();
guestList.pop();
console.log(guestList); // should output []
// Task 18
// Store the locations in an array
let places = ['Tokyo', 'Paris', 'New York', 'Bali', 'Sydney'];
// Print the array in its original order
console.log("Original order: ", places);
// Print the array in alphabetical order without modifying the actual list
console.log("Alphabetical order: ", places.slice().sort());
// Show that the array is still in its original order by printing it
console.log("Original order: ", places);
// Print the array in reverse alphabetical order without changing the order of the original list
console.log("Reverse alphabetical order: ", places.slice().sort().reverse());
// Show that the array is still in its original order by printing it again
console.log("Original order: ", places);
// Reverse the order of the list
places.reverse();
// Print the array to show that its order has changed
console.log("Reversed order: ", places);
// Reverse the order of the list again to bring it back to the original order
places.reverse();
// Print the array to show that it's back to its original order
console.log("Original order: ", places);
// Sort the array so it's stored in alphabetical order
places.sort();
// Print the array to show that its order has been changed
console.log("Alphabetical order: ", places);
// Sort the array to change it to reverse alphabetical order
places.sort().reverse();
// Print the array to show that its order has changed
console.log("Reverse alphabetical order: ", places);
//Task 19
console.log(`We can invite ${guestList.length} people to dinner.`);
//Task 20
let mountains = ['Mount Everest', 'K2', 'Kangchenjunga', 'Lhotse', 'Makalu'];
console.log(mountains);
//Task21
const person1 = {
    fistname: "Usman",
    lastname: "Ali",
    DOB: 2000,
    Age: 22
};
console.log(person1.fistname);
console.log(person1.lastname);
console.log(person1.DOB);
console.log(person1.Age);
//Task22
//let array = [1, 2, 3];
//console.log(array[3]); Index error in this program Correct is on the next line
let array = [1, 2, 3];
console.log(array[2]);
//Task 23
let car = 'subaru';
// Test 1
console.log("Is car == 'subaru'? I predict True.");
console.log(car == 'subaru');
// Test 2
console.log("Is car == 'honda'? I predict False.");
console.log(car == 'honda');
// Test 3
console.log("Is car != 'toyota'? I predict True.");
console.log(car != 'toyota');
// Test 4
console.log("Is car != 'subaru'? I predict False.");
console.log(car != 'subaru');
// Test 5
console.log("Is car === 'Subaru'? I predict False.");
console.log(car === 'Subaru');
// Test 6
console.log("Is car !== 'subaru'? I predict False.");
console.log(car !== 'subaru');
// Test 7
console.log("Is car !== 'toyota'? I predict True.");
console.log(car !== 'toyota');
// Test 8
console.log("Is car > 'ford'? I predict True.");
console.log(car > 'ford');
// Test 9
console.log("Is car < 'honda'? I predict False.");
console.log(car < 'honda');
// Test 10
console.log("Is car >= 'subaru'? I predict True.");
console.log(car >= 'subaru');
//Task 24
// Tests for equality and inequality with strings:
let color = 'red';
console.log("Is color == 'red'? I predict True.");
console.log(color == 'red');
console.log("Is color == 'blue'? I predict False.");
console.log(color == 'blue');
console.log("Is color != 'green'? I predict True.");
console.log(color != 'green');
console.log("Is color != 'red'? I predict False.");
console.log(color != 'red');
//Tests using the lower case function
let fruit = 'APPLE';
console.log("Is fruit.toLowerCase() == 'apple'? I predict True.");
console.log(fruit.toLowerCase() == 'apple');
console.log("Is fruit.toLowerCase() == 'orange'? I predict False.");
console.log(fruit.toLowerCase() == 'orange');
//Numerical tests involving equality and inequality, greater than and less than, greater than or equal to, and less than or equal to:
let x = 5;
let y = 10;
console.log("Is x == y? I predict False.");
console.log(x == y);
console.log("Is x != y? I predict True.");
console.log(x != y);
console.log("Is x < y? I predict True.");
console.log(x < y);
console.log("Is x > y? I predict False.");
console.log(x > y);
console.log("Is x <= y? I predict True.");
console.log(x <= y);
console.log("Is x >= y? I predict False.");
console.log(x >= y);
//Tests using "and" and "or" operators:
let age = 25;
let income = 50000;
console.log("Is age > 18 and income > 40000? I predict True.");
console.log(age > 18 && income > 40000);
console.log("Is age > 30 or income > 60000? I predict False.");
console.log(age > 30 || income > 60000);
//Test whether an item is in a array:
let numbers = [1, 3, 5, 7, 9];
console.log("Is 5 in the array? I predict True.");
console.log(numbers.includes(5));
console.log("Is 2 in the array? I predict False.");
console.log(numbers.includes(2));
//Test whether an item is not in a array:
let colors = ['red', 'green', 'blue'];
console.log("Is 'yellow' not in the array? I predict True.");
console.log(!colors.includes('yellow'));
console.log("Is 'red' not in the array? I predict False.");
console.log(!colors.includes('red'));
//Task 25
let alien_color = 'green';
if (alien_color === 'green') {
    console.log("You just earned 5 points!");
}
//part2
if (alien_color === 'red') {
    console.log("You just earned 5 points!");
}
//Task26
if (alien_color === 'green') {
    console.log("You just earned 5 points!");
}
else {
    console.log("You have earned 10 points!");
}
if (alien_color === 'red') {
    console.log("You just earned 5 points!");
}
else {
    console.log("You have earned 10 points!");
}
//Task 27
let alien_color1 = 'green';
if (alien_color1 === 'green') {
    console.log("You have earned five 5 points");
}
let alien_color2 = 'yellow';
if (alien_color2 === 'yellow') {
    console.log("You have earned five 10 points");
}
let alien_color3 = 'red';
if (alien_color3 === 'red') {
    console.log("You have earned five 15 points");
}
//Task 28
let age1 = 30;
if (age < 2) {
    console.log("This person is a baby.");
}
else if (age1 >= 2 && age1 < 4) {
    console.log("This person is a toddler.");
}
else if (age1 >= 4 && age1 < 13) {
    console.log("This person is a kid.");
}
else if (age1 >= 13 && age1 < 20) {
    console.log("This person is a teenager.");
}
else if (age1 >= 20 && age1 < 65) {
    console.log("This person is an adult.");
}
else {
    console.log("This person is an elder.");
}
//Task 29
let favorite_fruits = ['apple', 'orange', 'banana'];
if (favorite_fruits.includes('banana')) {
    console.log("You really like bananas");
}
if (favorite_fruits.includes('orange')) {
    console.log("You really like oranges");
}
if (favorite_fruits.includes('apple')) {
    console.log("You really like apples");
}
//Task 30
let usernames = ['admin', 'Usman', 'Ali', 'Danyal', 'JoJo'];
for (let i = 0; i < usernames.length; i++) {
    if (usernames[i] === 'admin') {
        console.log(`Hello admin, would you like to see a status report?`);
    }
    else {
        console.log(`Hello ${usernames[i]}, thank you for logging in again.`);
    }
}
//Task 31
usernames.pop();
usernames.pop();
usernames.pop();
usernames.pop();
usernames.pop();
if (usernames.length === 0) {
    console.log("We need to find some users!");
}
else {
    for (let i = 0; i < usernames.length; i++) {
        if (usernames[i] === "admin") {
            console.log("Hello admin, would you like to see a status report?");
        }
        else {
            console.log(`Hello ${usernames[i]}, thank you for logging in again.`);
        }
    }
}
//Task 32
let current_users = ['usman', 'ali', 'jojo', 'danyal', 'jutt'];
let new_users = ['usman', 'chaudary', 'sheikh', 'bhatti', 'jutt'];
for (let i = 0; i < new_users.length; i++) {
    if (current_users.includes(new_users[i])) {
        console.log("Sorry, the username '" + new_users[i] + "' is already taken. Please enter a new username.");
    }
    else {
        console.log("The username '" + new_users[i] + "' is available.");
    }
}
//Task 33
let numbers1 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
for (let number of numbers1) {
    if (number === 1) {
        console.log(number + "st");
    }
    else if (number === 2) {
        console.log(number + "nd");
    }
    else if (number === 3) {
        console.log(number + "rd");
    }
    else {
        console.log(number + "th");
    }
}
//Task 34
let pizza = ['Lasaania', 'BBQ', 'Fajita'];
for (let i = 0; i < pizza.length; i++) {
    console.log(`I like ${pizza[i]}, Pizza`);
}
//Task 35
let animals = ['cat', 'dog', 'rabbit'];
for (let animal of animals) {
    console.log(animal);
}
for (let animal of animals) {
    console.log(`A ${animal} would make a great pet.`);
}
console.log("Any of these animals would make a great pet!");
//Task 36
function make_shirt(size, message) {
    console.log(`Making a ${size} shirt with the message "${message}" printed on it.`);
}
make_shirt("large", "I love JavaScript");
//Task 37
function make_shirt1(size = 'large', message = 'I love TypeScript') {
    console.log(`Making a ${size} shirt with the message: "${message}"`);
}
make_shirt1();
make_shirt1('medium');
make_shirt1('small', 'JavaScript is awesome!');
//task 38
function describe_city(city, country) {
    console.log(`${city} is in ${country}.`);
}
describe_city("Karachi", "Pakistan");
describe_city("New York", "USA");
describe_city("London", "UK");
//Task 39
function describe_city1(city, country) {
    console.log(`\`${city},${country}\``);
}
describe_city1('Lahore', 'Pakistan');
//Task 40
function make_album(artist_name, album_title, num_tracks) {
    let album = {
        'artist': artist_name,
        'title': album_title
    };
    if (num_tracks) {
        album = num_tracks;
    }
    return album;
}
let album1 = make_album('Led Zeppelin', 'IV', 8);
let album2 = make_album('The Beatles', 'Abbey Road', 2);
let album3 = make_album('Pink Floyd', 'The Wall', 26);
console.log(album1);
console.log(album2);
console.log(album3);
//task 41
function show_magicians(magicians) {
    for (let i = 0; i < magicians.length; i++) {
        console.log(magicians[i]);
    }
}
let magicians = ["Harry Houdini", "David Blaine", "David Copperfield", "Penn Jillette", "Teller"];
show_magicians(magicians);
//task 42
function show_magicians1(magicians2) {
    for (let i = 0; i < magicians2.length; i++) {
        console.log("The Great", magicians2[i]);
    }
}
let magicians2 = ["Harry Houdini", "David Blaine", "David Copperfield", "Penn Jillette", "Teller"];
show_magicians(magicians2);
